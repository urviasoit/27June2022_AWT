# wikiapp/urls.py
from django.urls import path, include
from .views import search_wikipedia,download_file

urlpatterns = [
    path('search/', search_wikipedia, name='search_wikipedia'),
    path('<str:filename>', download_file, name='download_file'),
]
