
# wikiapp/views.py
from django.conf import settings
from django.shortcuts import render
from django.http import FileResponse 
from .forms import SearchForm
from django.template import loader
import wikipediaapi
import requests
import os

def fetch_wikipedia_content(query):
    user_agent = "myapp/1.0"
    headers = {'User-Agent': user_agent}
    url = f'https://en.wikipedia.org/w/api.php?action=query&prop=extracts&format=json&exintro=true&titles={query}'

    response = requests.get(url, headers=headers)
    data = response.json()

    # Extract the page content
    page = next(iter(data['query']['pages'].values()), None)
    if page and 'extract' in page:
        return page['extract']
    else:
        return "No Wikipedia page found for the given query."


def save_to_file(content, filename):
    file_path = os.path.join(settings.BASE_DIR, filename)
    with open(file_path, 'w', encoding='utf-8') as file:
         file.write(content)

def download_file(request, filename):
    file_path = os.path.join(settings.BASE_DIR, filename)

    if os.path.exists(file_path):
        with open(file_path, 'rb') as file:
            response = FileResponse(file)
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            return response
    else:
        return render(request, 'myapp/error.html', {'error_message': 'File not found'})


def search_wikipedia(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            search_query = form.cleaned_data['search_query']
            result = fetch_wikipedia_content(search_query)

            output_file = f"{search_query}_wikipedia_explanation.txt"
            save_to_file(result, output_file)

            success_message = f"File downloaded successfully. You can find it at: {os.path.abspath(output_file)}"
            return render(request, 'myapp/success.html', {'success_message': success_message})
    else:
        form = SearchForm()

    return render(request, 'myapp/search.html', {'form': form})

# Create your views here.
