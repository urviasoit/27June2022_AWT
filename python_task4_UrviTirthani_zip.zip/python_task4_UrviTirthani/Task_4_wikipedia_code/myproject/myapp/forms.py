# wikiapp/forms.py
from django import forms

class SearchForm(forms.Form):
    search_query = forms.CharField(label='Enter a word', max_length=100)
