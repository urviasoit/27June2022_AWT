# myapp/models.py
from django.db import models

class DataFrameEntry(models.Model):
    firstname = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255)
    city = models.CharField(max_length=255)
    college = models.CharField(max_length=255)
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
          return f"{self.firstname} - {self.date_created}"

# Create your models here.
