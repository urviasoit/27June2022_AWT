# myapp/forms.py
from django import forms
from .models import DataFrameEntry

class DataFrameForm(forms.ModelForm):
    class Meta:
        model = DataFrameEntry
        fields = ['firstname', 'lastname', 'city', 'college']
