# myapp/urls.py
from django.urls import path
from .views import upload_dataframe, upload_success, render_dataframe

urlpatterns = [
    path('upload/', upload_dataframe, name='upload_dataframe'),
    path('upload/success/', upload_success, name='upload_success'),
    path('render/', render_dataframe, name='render_dataframe'), 
]
