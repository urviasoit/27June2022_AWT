# myapp/views.py
from django.shortcuts import render, redirect
from .forms import DataFrameForm
from .models import DataFrameEntry

def upload_dataframe(request):
    if request.method == 'POST':
        form = DataFrameForm(request.POST)
        if form.is_valid():
            form.save()
            return render_dataframe(request)
    else:
        form = DataFrameForm()

    return render(request, 'myapp/upload_dataframe.html', {'form': form})

def render_dataframe(request):
    entries = DataFrameEntry.objects.all()
    return render(request, 'myapp/render_dataframe.html', {'entries': entries})

    
def upload_success(request):
    return render(request, 'myapp/upload_success.html')

# Create your views here.
