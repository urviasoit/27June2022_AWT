$(document).ready(function(){
$("#b1").click(function(){
    $("#b2").toggle();
});
$("#b1").click(function(){
    $("#b3").toggle();
});
});