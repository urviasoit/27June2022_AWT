import pyttsx3
import speech_recognition as sr
import webbrowser
import datetime
import pyjokes
import os
import time
 

 
def sptext():                                                           #to convert speech to text     
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:                                    #listens user voice
        print("   Listening....  ")
        recognizer.adjust_for_ambient_noise(source)                   #to improve voice and removes noise
        audio = recognizer.listen(source)
        try:
            print(" Recognizing.. Plz wait for a minute  ")
            data = recognizer.recognize_google(audio)
            return data
        except sr.UnknownValueError :
            print("  Not Understand   ")
            return ''
            
def speechtx(x):                                                                        #to convert text to speech       
    engine=pyttsx3.init()
    voices = engine.getProperty('voices')
    engine.setProperty('voice',voices[0].id)                                  #1-male voice ||  2-female voice
    rate = engine.getProperty('rate')
    engine.setProperty('rate',150)                                      #speaking speed
    engine.say(x)
    engine.runAndWait()


if __name__=='__main__':


        if "hey siri" in sptext().lower():
            while True:
                    data1=sptext().lower()

                    if "your name" in data1:
                        name="my name is siri"
                        speechtx(name)
                        
                    elif "old are you" in data1:
                        age = "i am two years old"
                        speechtx(age)
                       
                    elif "siri" in data1:
                        nm="hello welcome to the presentation"
                        speechtx(nm)

                    elif "time" in data1:
                        time=datetime.datetime.now().strftime("%I%M%p")
                        speechtx(time)

                    elif "youtube" in data1:
                        webbrowser.open("https://www.youtube.com/")

                    elif "web" in data1:
                        webbrowser.open("https://www.bing.com/")

                    elif "joke" in data1:
                        joke_1=pyjokes.get_joke(language="en",category="neutral")
                        print(joke_1)
                        speechtx(joke_1)

                    elif "play song" in data1:
                        add="D:\songss"
                        song = os.listdir(add)
                        print(song)
                        os.startfile(os.path.join(add, song[0]))

                    elif "exit" in data1:
                        speechtx("thank you")
                        break
                    
                    time.sleep(3)
        else:
            print("thanks")

            