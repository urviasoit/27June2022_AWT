
# Create your models here.
# registeration/models.py
from django.db import models

class atomic(models.Model):
    username = models.CharField(max_length=255)
    email = models.EmailField()
    password = models.CharField(max_length=255)  # Note: This is just an example, consider using Django's built-in User model for password management

    def __str__(self):
        return self.username
