# registeration/forms.py
from django import forms
from .models import atomic

class atomicForm(forms.ModelForm):
    class Meta:
        model = atomic
        fields = ['username', 'email', 'password']
