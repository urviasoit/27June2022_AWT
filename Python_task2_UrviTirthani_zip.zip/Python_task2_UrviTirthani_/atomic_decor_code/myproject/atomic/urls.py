# registeration/urls.py
from django.urls import path
from .views import view_table, register_user

urlpatterns = [
    path('view-table/', view_table, name='view_table'),
    path('register-user/', register_user, name='register_user'),
]
