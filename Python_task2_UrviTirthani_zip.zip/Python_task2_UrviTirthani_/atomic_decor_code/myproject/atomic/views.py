from django.shortcuts import render

# Create your views here.
# registeration/views.py
from django.shortcuts import render, redirect
from .forms import atomicForm
from .models import atomic

def view_table(request):
    entries = atomic.objects.all()
    return render(request, 'atomic/view_table.html', {'entries': entries})

def register_user(request):
    if request.method == 'POST':
        form = atomicForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_table')
    else:
        form = atomicForm()

    return render(request, 'atomic/register_user.html', {'form': form})
