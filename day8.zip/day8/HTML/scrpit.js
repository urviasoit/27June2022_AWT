function al(){
    alert('hello world');
}

console.log('hello')

function color(){
    document.body.style.backgroundColor="blue"
    
}
function A1(){
    document.getElementById('awt').style.backgroundColor="blue";
}
function InternalAlertJs(){
    document.getElementById('awt').style.backgroundColor="blue";
}

