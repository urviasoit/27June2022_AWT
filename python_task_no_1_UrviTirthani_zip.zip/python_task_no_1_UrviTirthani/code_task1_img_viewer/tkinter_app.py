from tkinter import *
from PIL import ImageTk, Image

def resize_image(img_path, height, width):
    img = Image.open(img_path)
    img = img.resize((width, height), Image.ANTIALIAS)
    return ImageTk.PhotoImage(img)

window = Tk()
window.title('Image Viewer')  
window.geometry("650x600")  
#window.config(bg="")
#window.resizable(True, True)  

Label(window, text="Multiple Image Viewer",font=('bold', 20)).pack()  # label

Frames = Frame(window, width=340, height=340)  
Frames.pack()

def backward():
    global j  
    j = j - 1
    if j < 0:
        j = len(imglst) - 1
    img_label.config(image=imglst[j])
    update_buttons()

back_button = Button(window, text='Back', bg='#ADD8E6' , command=backward)
back_button.place(x=85, y=200)

def forward():
    global j  
    j = (j + 1) % len(imglst)
    img_label.config(image=imglst[j])
    update_buttons()

next_button = Button(window, text='Next',bg='#ADD8E6', command=forward)
next_button.place(x=530, y=200)

img1 = resize_image("img1.jpg", 400, 400)
img2 = resize_image("img_2.jpg", 400, 400)
img3 = resize_image("img_3.jpeg", 400, 400)
img4 = resize_image("img_4.jpeg", 400, 400)
imglst = [img1, img2, img3,img4]
j = 0
img_label = Label(Frames, image=imglst[j])

img_label.pack()

def update_buttons():
    if j == 0:
        back_button.config(state=DISABLED)
    else:
        back_button.config(state=NORMAL)

    if j == len(imglst) - 1:
        next_button.config(state=DISABLED)
    else:
        next_button.config(state=NORMAL)


update_buttons()  
window.mainloop()
