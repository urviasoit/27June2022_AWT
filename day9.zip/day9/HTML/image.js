function chaimg1(){
    document.getElementById("trns1").src="p1.jpeg"
}

function chaimg2(){
    document.getElementById("trns1").src="p2.jpeg"

}

function chaimg3(){
    document.getElementById("trns1").src="p3.jpg"

}