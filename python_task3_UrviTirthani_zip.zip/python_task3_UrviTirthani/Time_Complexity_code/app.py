import ast

def estimate_time_complexity(code):
    
    tree = ast.parse(code)

    
    def traverse(node):
        complexity = 0
        if isinstance(node, ast.For):
            iter_complexity = traverse(node.iter) 
            body_complexity = traverse(node.body)  
            complexity += iter_complexity * body_complexity  
        elif isinstance(node, ast.While):
            test_complexity = traverse(node.test) 
            body_complexity = traverse(node.body)  
            complexity += test_complexity * body_complexity  
        elif isinstance(node, ast.FunctionDef):
            complexity = max(complexity, traverse(node.body))  
        elif isinstance(node, ast.Call):
            complexity += traverse(node.func)  
        else:
            complexity += 1 
        return complexity

    total_complexity = traverse(tree)
    if total_complexity <= 1:
        return "O(1)"
    elif total_complexity <= 2:
        return "O(log n)"  
    else:
        return f"O(n^{total_complexity})"

code = """
for i in range(9):
    print(i)

while j > 0:
    j //= 2

def my_function(k):
    for k in range(7):
        print(k)
"""

complexity = estimate_time_complexity(code)
print(complexity)

